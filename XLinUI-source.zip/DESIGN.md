# v0.4.0 设计和接口参考

本次按用户给出的顶部状态栏及六张弹出面板截图重做。BIS 入口明确去除。

## 查阅的 FF14 UI 项目

- [Umbra](https://github.com/una-xiv/umbra)：直接相关的工具栏/弹出面板设计。查阅 BattleEffects 和 OnlineStatus 等接口用法，核对战斗特效设置为 0=完全、1=简单、2=关闭，召唤兽尺寸为 0=小、1=中、2=大。
- [DelvUI](https://github.com/DelvUI/DelvUI)：可定制替代 HUD 和资源条设计。
- [FFXIV Material UI](https://github.com/skotlex/ffxiv-material-ui)：原版 UI 视觉皮肤参考；本项目不安装其贴图包，也不修改原版资源。
- [ChatTwo](https://github.com/Infiziert90/ChatTwo)：聊天侧栏、可变字号与过滤等交互参考。本项目未完整实现其富文本和无限标签能力。
- [FFXIVClientStructs](https://github.com/aers/FFXIVClientStructs)：核对游戏已有设置、装备、声望、传送等类型和调用接口。
- [FFXIV datamining](https://github.com/xivapi/ffxiv-datamining)：核对普通动作 ID、在线状态与货币表；实际名称/图标使用玩家客户端数据。

参考界面和 API 事实；弹出面板采用本项目的 ImGui 实现，没有把上述插件安装或嵌入为运行依赖。

## 原版组件与读取范围

原版热键栏和战斗状态采用保留游戏渲染的方式，不重画一组看起来相似的图标，因此游戏现有键位、缩放、隐藏设置、冷却、目标和工具提示继续由游戏管理。自定义 HP/MP（或 GP/CP）和顶部信息分别替代 Parameter、DTR 根节点，停用时恢复原先可见状态。

读取当前已加载窗口的位置、比例和尺寸，尚未加载的窗口稍后补充。位置/尺寸变化继续记录；插件位置导入时限制在屏幕内。没有读取全部游戏配置文件或所有 HUD 档案。角色退出后清空会话窗口记录。

## 截图功能映射

特效 → 游戏 UiConfig；部族 → PlayerState/QuestManager 及 BeastTribe 表；在线 → 正常状态选择与个人搜索信息；职业 → 已保存的 RaptureGearsetModule 套装；装备 → EquippedItems 的耐久/精炼度；货币 → 原生计数、物品表上限及军票/周限专用接口；传送 → 当前 Telepo 列表；插件 → 已加载插件元数据；指令 → ICommandManager 当前注册表；外部 AI 等状态 → IDtrBar 已公开条目。

原版修理/精制/镶嵌动作 ID 分别为 6/14/12，来自 GeneralAction 表；用户点击才调用。不会进行自动修理、自动传送或自动执行插件指令。

## 限制

面板视觉不是对参考截图的逐像素复制；需要用户本机反馈才能核对实际字号、语言和布局。其他插件的私有状态没有通用读取方式；仅自动发现公开 DTR 项。DTR 人工事件的 AtkEventSource 为空，要求原生事件数据的插件可能需要专门适配。货币列表基于当前容器、持有数量及在役神典石，不保证覆盖所有专用钱包。个人搜索信息在游戏社交缓存未就绪时可能无法打开。没有 BIS、真实背景模糊或完整原版窗口重写。

测试验证管理状态和配置，不能替代 soil 游戏内对新增原生接口与各个 DTR 提供者的验证。
